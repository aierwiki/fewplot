# @Author: Tang Yubin <tangyubin>
# @Date:   2019-05-26T12:03:50+08:00
# @Email:  tang-yu-bin@qq.com
# @Last modified by:   tangyubin
# @Last modified time: 2019-05-26T12:09:13+08:00
name = 'fewplot'
