# fewplot
a easy way to plot with few arguments
